﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElPaisScraper
{
    public class BrowserCapabality
    {
        public string? Browser { get; set; }
        public string? BrowserVersion { get; set; }
        public string? Os { get; set; }
        public string? OsVersion { get; set; }
        public string? Device { get; set; }
        public bool? RealMobile { get; set; }
    }
}
