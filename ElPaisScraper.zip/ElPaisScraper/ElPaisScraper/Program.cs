﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace ElPaisScraper
{
    class Program
    {
        private const string BrowserStackUser = "yashas_7sv5E1";
        private const string BrowserStackKey = "shQXQafsL4HUQYJZfHp6";
        private const string BuildName = "browserstack-build-1";
        private const string ProjectName = "ElpaisScraper";

        static async Task Main(string[] args)
        {
            await ExecuteCrossBrowserTests();
        }

        public static async Task<IWebDriver> GetBrowserStackDriverAsync(string os, string osVersion, string browserName, string browserVersion)
        {
            var options = new ChromeOptions();
            options.PlatformName = os;
            options.BrowserVersion = osVersion;
            options.PlatformName = browserName;
            options.BrowserVersion = browserVersion;

            // Add BrowserStack credentials
            options.AddAdditionalChromeOption("browserstack.user", BrowserStackUser);
            options.AddAdditionalChromeOption("browserstack.key", BrowserStackKey);
            options.AddAdditionalChromeOption("build", BuildName);
            options.AddAdditionalChromeOption("project", ProjectName);
            options.AddAdditionalChromeOption("name", "Cross-Browser Testing");

            return new RemoteWebDriver(new Uri("https://yashas_7sv5E1:shQXQafsL4HUQYJZfHp6@hub-cloud.browserstack.com/wd/hub"), options);
        }

        public static async Task ExecuteCrossBrowserTests()
        {
            var tasks = new List<Task>();

            tasks.Add(Task.Run(async () =>
            {
                var driver = await GetBrowserStackDriverAsync("Windows", "11", "Chrome", "latest");
                await RunScraperAndTranslate(driver);
                driver.Quit();
            }));

            tasks.Add(Task.Run(async () =>
            {
                var driver = await GetBrowserStackDriverAsync("OS X", "Monterey", "Safari", "15.6");
                await RunScraperAndTranslate(driver);
                driver.Quit();
            }));

            tasks.Add(Task.Run(async () =>
            {
                var driver = await GetBrowserStackDriverAsync("iPhone", "15", "Chromium", "latest");
                await RunScraperAndTranslate(driver);
                driver.Quit();
            }));

            await Task.WhenAll(tasks);
        }

        private static async Task RunScraperAndTranslate(IWebDriver driver)
        {
            try
            {
                var scraper = new WebScraper(driver);
                await scraper.ScrapeAndTranslate();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}

//using OpenQA.Selenium.Chrome;
//using OpenQA.Selenium;
//using Newtonsoft.Json;
//using RestSharp;
//using OpenQA.Selenium.Support.UI;
//using System;
//using System.IO;
//using System.Net.Http;
//using System.Threading.Tasks;
//using System.Linq;

//namespace ElPaisScraper
//{
//    class Program
//    {
//        static async Task Main(string[] args)
//        {
//            var options = new ChromeOptions();
//            options.AddArgument("--start-maximized");
//            options.AddArgument("--disable-notifications");

//            using (IWebDriver driver = new ChromeDriver(options))
//            {
//                var webScraper = new WebScraper(driver);
//                await webScraper.ScrapeAndTranslate();
//            }
//        }
//    }
//}
