﻿using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using Newtonsoft.Json;
using RestSharp;
using OpenQA.Selenium.Support.UI;

namespace ElPaisScraper
{
    public class WebScraper
    {
        private readonly IWebDriver _driver;

        public WebScraper(IWebDriver driver)
        {
            _driver = driver;
        }

        public async Task ScrapeAndTranslate()
        {

            var options = new ChromeOptions();
            options.AddArgument("--start-maximized");
            options.AddArgument("--disable-notifications");


            //using IWebDriver driver = new ChromeDriver(options);

            try
            {
                _driver.Navigate().GoToUrl("https://elpais.com/");
                Console.WriteLine("Website loaded.");

                try
                {
                    var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(30));
                    var acceptButton = wait.Until(d => d.FindElement(By.XPath("//*[@id='didomi-notice-agree-button']"))); ////*[@id="didomi-notice-agree-button"]
                    if (acceptButton.Displayed && acceptButton.Enabled)
                    {
                        acceptButton.Click();
                        Console.WriteLine("Accepted cookies.");
                    }
                }
                catch (WebDriverTimeoutException)
                {
                    Console.WriteLine("Cookie popup did not appear or could not be detected.");
                }

                try
                {
                    var opinionLink = _driver.FindElement(By.XPath("/html/body/main/div[3]/section[1]/header/div/a"));
                    opinionLink.Click();
                    Console.WriteLine("Navigated to the Opinion section.");
                }
                catch (NoSuchElementException ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }

                var articles = _driver.FindElements(By.CssSelector("article.c")).Take(5).ToList();

                if (articles.Count == 0)
                {
                    Console.WriteLine("No articles found. Please verify the selector or page structure.");
                    return;
                }

                articles[0].FindElement(By.CssSelector("h2.c_t > a")).Click(); // Open the first article
                Console.WriteLine("Opened the first article.");

                List<string> translatedTitles = new();

                for (int i = 0; i < 5; i++)
                {
                    try
                    {
                        var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(10));


                        // Wait for the content section
                        var contentSection = wait.Until(d => d.FindElement(By.CssSelector("div.a_c.clearfix")));
                        string title = _driver.FindElement(By.CssSelector("h1.a_t")).Text; // Main article title
                        string content = string.Join("\n", contentSection
                                             .FindElements(By.TagName("p"))
                                             .Select(p => p.Text));

                        // Extract the image URL (if available)
                        var imgElement = wait.Until(d => d.FindElement(By.CssSelector("div.a_e_m img")));
                        string imageUrl = imgElement?.GetAttribute("src");

                        Console.WriteLine($"Title: {title}");
                        Console.WriteLine($"Content: {content}");

                        // Save cover image locally
                        if (!string.IsNullOrEmpty(imageUrl))
                        {
                            await DownloadImageAsync(imageUrl, title);
                        }

                        // Translate title
                        string translatedTitle = await TranslateTitleAsync(title);
                        translatedTitles.Add(translatedTitle);
                        Console.WriteLine($"Translated Title: {translatedTitle}");

                        // Find and click the "Next Article" link in the "Más información" section
                        var nextArticleLink = wait.Until(d => d.FindElement(By.CssSelector("div._g._g-xs.w-rel_n h3.nt_t a"))); // Adjust selector as needed
                        ((IJavaScriptExecutor)_driver).ExecuteScript("arguments[0].scrollIntoView(true);", nextArticleLink);
                        ((IJavaScriptExecutor)_driver).ExecuteScript("arguments[0].click();", nextArticleLink);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error while processing article {i + 1}: {ex.Message}");
                        break; // Stop the loop on failure
                    }
                }

                // Analyze translated headers
                AnalyzeHeaders(translatedTitles);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        private async Task<string> TranslateTitleAsync(string title)
        {
            string apiKey = "AIzaSyAPvo-OdUkv2zS5rxnshoD-bsQOnYi8Ifs";
            string url = $"https://translation.googleapis.com/language/translate/v2?key={apiKey}";

            var client = new RestClient(url);
            var request = new RestRequest();
            request.Method = Method.Post;
            request.AddJsonBody(new { q = title, target = "en" });

            var response = await client.ExecuteAsync(request);
            if (response.IsSuccessful)
            {
                var result = JsonConvert.DeserializeObject<dynamic>(response.Content);
                return result.data.translations[0].translatedText.ToString();
            }
            return "Translation failed";
        }
        private void AnalyzeHeaders(List<string> headers)
        {
            var wordCounts = headers
                .SelectMany(title => title.Split(' '))
                .GroupBy(word => word.ToLower())
                .Where(group => group.Count() > 2)
                .ToDictionary(group => group.Key, group => group.Count());

            Console.WriteLine("Repeated Words:");
            foreach (var word in wordCounts)
            {
                Console.WriteLine($"{word.Key}: {word.Value}");
            }
        }
        static async Task DownloadImageAsync(string imageUrl, string fileName)
        {
            using (HttpClient client = new HttpClient())
            {
                byte[] imageBytes = await client.GetByteArrayAsync(imageUrl);
                string filePath = Path.Combine("Images", $"{fileName}.jpg");
                Directory.CreateDirectory(Path.GetDirectoryName(filePath));
                await File.WriteAllBytesAsync(filePath, imageBytes);
                Console.WriteLine($"Image saved to: {filePath}");
            }
        }

    }
}
